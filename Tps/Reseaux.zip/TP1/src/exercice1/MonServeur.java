package exercice1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;


public class MonServeur {

  private Socket socket;
  private ServerSocket serveur;
  private int numconnexion;
  private List<String> historique = new ArrayList<String>();

  public MonServeur(int port) throws IOException {
    try {
	   this.serveur = new ServerSocket(port);
    } catch (IOException e) {
	   System.out.println("le port "+port+" est indisponible. Pas de connexion possible.");
    }
  }

  public void envoiMessage() throws IOException {
     while (true){
	   this.socket = this.serveur.accept();
	   this.numconnexion++;
	   this.historique.add(this.socket.getInetAddress().getHostAddress());
	    try {
	    //un petit jeu d'essai,où l'utilisateur tape une chaine de caractère et le serveur la lui affiche
	      PrintStream p = new PrintStream(this.socket.getOutputStream());
	      p.println("***********************************************************************");
	      p.print("Bienvenue sur le serveur de Nassim , adresse : "+this.historique.get(this.numconnexion-1)+" , connexion n°");
	      p.println(this.numconnexion-1);
	      p.println("***********************************************************************");
	      p.println("--Tapez ce que vous voulez , on vous l'affichera à l'écran  !!--");
	      p.println("pour quitter tapez (bye)");
	      String msg = new BufferedReader(new InputStreamReader(this.socket.getInputStream())).readLine();
	      while (msg.compareTo("bye") != 0) {
		      PrintStream ps = new PrintStream(this.socket.getOutputStream());
		      ps.println(msg);
		      msg = new BufferedReader(new InputStreamReader(this.socket.getInputStream())).readLine();
	      }
	    }
		  catch (IOException e) { 
		  System.out.println("!Pas de connexion!"); 
		}
		this.socket.close();
     }
    }
	
	public static void main(String args[]) throws IOException {
		MonServeur testServeur = new MonServeur(2323);
		testServeur.envoiMessage();
	}
	
}
