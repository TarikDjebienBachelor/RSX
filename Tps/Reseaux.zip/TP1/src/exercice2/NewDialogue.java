package exercice2;

import java.io.*;
import java.net.*;
import java.util.*;


public class NewDialogue implements Runnable{
	private static ServerSocket ss;
	private Socket socket;
	private InputStream in;
	private PrintStream ps;
	private int numero;
	private static int connexions = 0;
	private static int total = 0;
	private static int MAX = 20;
	private static Set<NewDialogue> active;
	private static String[] infoConnexions = new String[MAX];
	
	public NewDialogue(Socket s) {
		this.socket = s;
		NewDialogue.infoConnexions[NewDialogue.total++] = s.getInetAddress().getHostName();
		this.numero = ++NewDialogue.connexions;
	}
	
	public void run() {
		String msg="";
		try {
			while (true) {		
				this.in = this.socket.getInputStream();
				msg = new BufferedReader(new InputStreamReader(this.in)).readLine();
				NewDialogue.broadcast(this,msg);
				if (msg.startsWith("bye")) break;	
			}
			active.remove(this);
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void broadcast(NewDialogue d, String msg) {
		synchronized (active) {
			for (NewDialogue dd: active)
				dd.print_message(d,msg);
		}
	}
	
	private void print_message(NewDialogue d, String msg){
		try {
			this.ps = new PrintStream(this.socket.getOutputStream());
			ps.print("<"+d.numero+">");
			ps.println(msg);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			ss = new ServerSocket(4242);
			active = Collections.synchronizedSet(new HashSet<NewDialogue>());
			while (true) {
				Socket s = ss.accept();
				if (total+1 == MAX) {s.close(); continue;}
				NewDialogue d = new NewDialogue(s);
				OutputStream out = d.socket.getOutputStream();
				PrintStream p = new PrintStream (out);
				p.println("Bienvenue sur mon serveur, "+infoConnexions[d.numero-1]);
				p.println("Connexion n�"+d.numero);
				active.add(d);
				Thread t = new Thread(d);
				t.start();
			}
		}
		catch (IOException e){
			System.out.print(e.getMessage());
		}
	}
}
