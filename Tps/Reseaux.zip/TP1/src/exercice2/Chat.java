package exercice2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Chat implements Runnable{

	private static ServerSocket ss;
	private Socket socket;
	private InputStream in;
	private PrintStream ps;
	private int numero; //le numero de la connexion créé
	private static int connexions = 0;  
	private static int total = 0;  
	private static int MAX = 20;  //le nombre maximum des personnes pouvant communiquer
	private static Set<Chat> active;  //les connexion activé
	private static String[] historique = new String[MAX]; //
	
	public Chat(Socket s) {
		this.socket = s;
		this.historique[this.total++] = s.getInetAddress().getHostName();
		this.numero = ++this.connexions;
	}
	
	public void run() {
		String msg="";
		try {
			while (true) {		
				this.in = this.socket.getInputStream();
				msg = new BufferedReader(new InputStreamReader(this.in)).readLine();
				this.broadcast(this,msg);
				if (msg.startsWith("bye")) break;	
			}
			active.remove(this);
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void broadcast(Chat d, String msg) {
		synchronized (active) {
			for (Chat dd: active)
				dd.envoiMessage(d,msg);
		}
	}
	
	private void envoiMessage(Chat d, String msg){
		try {
			this.ps = new PrintStream(this.socket.getOutputStream());
			ps.print("<"+d.numero+">");
			ps.println(msg);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			ss = new ServerSocket(4242);
			active = Collections.synchronizedSet(new HashSet<Chat>());
			while (true) {
				Socket s = ss.accept();
				if (total+1 == MAX) {s.close(); continue;}
				Chat d = new Chat(s);
				OutputStream out = d.socket.getOutputStream();
				PrintStream p = new PrintStream (out);
			    p.println("***********************************************************************");
				p.print("Bienvenue sur le serveur de Nassim , adresse : "+historique[d.numero-1]);
				p.println(" , Connexion n°"+d.numero);
			    p.println("***********************************************************************");
				active.add(d);
				Thread t = new Thread(d);
				t.start();
			}
		}
		catch (IOException e){
			System.out.print(e.getMessage());
		}
	}
}

