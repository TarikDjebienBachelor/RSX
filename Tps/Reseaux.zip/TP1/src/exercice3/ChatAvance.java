package exercice3;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.channels.Channel;
import java.nio.channels.SelectionKey;
import java.util.Collections;
import java.util.HashSet;

import com.sun.corba.se.pept.transport.Selector;

import exercice2.Chat;


//regarder le lien :   http://www.exampledepot.com/egs/java.nio/NbClient.html

public class ChatAvance{
	
	private static ServerSocket ss;
	private Socket socket;
	protected Selector select = null;
	private SelectionKey selectKey;
	

	
	public static void main(String[] args) {
		Selector selector = null; try { 
			// Create the selector 
			selector = Selector.open(); 
			// Create two non-blocking sockets. This method is implemented in 
			// Creating a Non-Blocking Socket. 
			SocketChannel sChannel1 = createSocketChannel("hostname.com", 80); 
			SocketChannel sChannel2 = createSocketChannel("hostname.com", 80); 
			// Register the channel with selector, listening for all events 
			sChannel1.register(selector, sChannel1.validOps()); sChannel2.register(selector, sChannel1.validOps()); } catch (IOException e) { }
		}
	}
}
