import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;

public class UDP {
	
	public static DatagramSocket Socket;
	public static boolean aff;
	
	public static DatagramPacket receive() throws IOException {
		
		byte[] buffer = new byte[1024];
		DatagramPacket dp = new DatagramPacket(buffer,buffer.length);
		Socket.receive(dp);
		if (aff) {
			System.out.print("<RECEIVE> ");
			System.out.println(new String(dp.getData()));
		}
		System.out.println();
		return dp;
		
	}
	
	public static void send(byte[] msg, InetAddress dest, int port) throws IOException {
			
			DatagramPacket dp = new DatagramPacket(msg,msg.length,dest,port);	
			Socket.send(dp);
	}
	
	public static void main(String args[]) throws SocketException {
		Socket = new DatagramSocket(5687);	
		aff = true;
		try {
				receive();
		} catch (IOException e2) {
			e2.printStackTrace();
		}
			
		
	}

}
