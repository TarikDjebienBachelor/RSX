public class IllegalRequestException extends Exception {

}
