public class IllegalMSGException extends Exception {

}
