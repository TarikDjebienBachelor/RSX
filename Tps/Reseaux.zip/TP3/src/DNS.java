import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.*;


public class DNS {
	
	public final static int PORT = 53;
	
	private static String name(byte[] buf,int offset) {
	
		if (offset==buf.length) return "";
		int n=0; String s,res,temp=""; res=""; boolean dep = false; s="";
		for (int i=offset; i<buf.length; i++) {
			if (buf[i]==0x00) break;
			s= Integer.toHexString(Integer.parseInt(Byte.toString(buf[i]))); 
			if (s.length()>=2) {
				s = s.substring(s.length()-2,s.length());
				if (s.equals("c0")) {
					dep = true;
					s = Integer.toHexString(Integer.parseInt(Byte.toString(buf[i+1])));
					if (s.length()>=2)
						s = s.substring(s.length()-2,s.length());
					else  s= "0"+s;
					offset = Integer.decode("0x"+s);
					break;
				}	
			}
			else s = "0"+s;
			temp+=s;
		}
		
		for (int j=0; j<temp.length();) {
			s = temp.substring(j,j+2);
			if (n==0) {
				n=Integer.decode("0x"+s);
				if (j!=0) res+=".";
				j+=2;  
				continue;
			}
			res+=new String(new byte[]{Integer.decode("0x"+s).byteValue()});
			j+=2; n--;
		}
		if (dep) return res+"."+name(buf,offset);
		return res;
		
	}
	
	public static long String2Int(String name) {
		try {
			InetAddress inet = InetAddress.getByName(name);
			String res = inet.getHostAddress();
			String a,b,c,d; int i,j;
			System.out.println("\n"+res);
			j=0;
			for (i=j; i< res.length(); i++) {
				if (res.charAt(i)=='.') break;
			}
			a = Integer.toHexString(Integer.parseInt(res.substring(j,i)));
			System.out.print(a+".");
			j=i+1;
			for (i=j; i< res.length(); i++) {
				if (res.charAt(i)=='.') break;
			}
			b = Integer.toHexString(Integer.parseInt(res.substring(j,i)));
			System.out.print(b+".");
			j=i+1;
			for (i=j; i< res.length(); i++) {
				if (res.charAt(i)=='.') break;
			}
			c = Integer.toHexString(Integer.parseInt(res.substring(j,i)));
			System.out.print(c+".");
			j=i+1;
			for (i=j; i< res.length(); i++) {
				if (res.charAt(i)=='.') break;
			}
			d = Integer.toHexString(Integer.parseInt(res.substring(j,i)));
			System.out.println(d);
			return Long.decode("0x"+a+b+c+d);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	
	public static void answer(byte[] buffer) throws IOException {
		
		int i=0; int n=0;
		for (byte b: buffer) {
			if (i%4==0) System.out.print(" ");
			System.out.print(b);
			i++;
		}
		System.out.println();
		String temp, s; temp = s = "";
		/*Header*/
		System.out.println("\nENTETE");
		//Id
		System.out.print("  Identifiant: ");
		for (i=0; i<2; i++) {
			s = Integer.toHexString(Integer.parseInt(Byte.toString(buffer[i])));
			if (s.length()>=2) s = s.substring(s.length()-2,s.length());
			else s = "0"+s;
			temp += s;
		}
		n=Integer.decode("0x"+temp);
		System.out.print(temp+" ("+n+")");
		//Params
		temp="";
		for (i=2; i<4; i++) temp += Integer.toBinaryString(Integer.parseInt(Byte.toString(buffer[i])));
		System.out.println("\n  Param�tres:");
		System.out.print("    QR: "); System.out.println(temp.charAt(0));
		System.out.print("    OPCODE: "); System.out.println(temp.substring(1, 5));
		System.out.print("    AA: "); System.out.println(temp.charAt(5));
		System.out.print("    TC: "); System.out.println(temp.charAt(6));
		System.out.print("    RD: "); System.out.println(temp.charAt(7));
		System.out.print("    RA: "); System.out.println(temp.charAt(8));
		System.out.print("    UNUSED: "); System.out.println(temp.charAt(9));
		System.out.print("    AD: "); System.out.println(temp.charAt(10));
		System.out.print("    CD: "); System.out.println(temp.charAt(11));
		System.out.print("    RCODE: "); System.out.println(temp.substring(12,16));
		//QDCount, ANCount, NSCount, ARCount
		int qdcount, ancount, nscount, arcount; 
		temp = "";
		System.out.print("  QDCount: "); 
		for (i=4; i<6; i++) {
			s = Integer.toHexString(Integer.parseInt(Byte.toString(buffer[i])));
			if (s.length()>=2) s = s.substring(s.length()-2,s.length());
			else s = "0"+s;
			temp += s;
		}
		qdcount = Integer.decode("0x"+temp); System.out.print(temp+" ("+qdcount+")");
		temp = "";
		System.out.print("\n  ANCount: "); 
		for (i=6; i<8; i++) {
			s = Integer.toHexString(Integer.parseInt(Byte.toString(buffer[i])));
			if (s.length()>=2) s = s.substring(s.length()-2,s.length());
			else s = "0"+s;
			temp += s;
		}
		ancount = Integer.decode("0x"+temp); System.out.print(temp+" ("+ancount+")");
		temp = "";
		System.out.print("\n  NSCount: "); 
		for (i=8; i<10; i++) {
			s = Integer.toHexString(Integer.parseInt(Byte.toString(buffer[i])));
			if (s.length()>=2) s = s.substring(s.length()-2,s.length());
			else s = "0"+s;
			temp += s;
		}
		nscount = Integer.decode("0x"+temp); System.out.print(temp+" ("+nscount+")");
		temp = "";
		System.out.print("\n  ARCount: "); 
		for (i=10; i<12; i++) {
			s = Integer.toHexString(Integer.parseInt(Byte.toString(buffer[i])));
			if (s.length()>=2) s = s.substring(s.length()-2,s.length());
			else s = "0"+s;
			temp += s;
		}
		arcount = Integer.decode("0x"+temp); System.out.print(temp+" ("+arcount+")");
		
		//Question
		if (qdcount>0) {
			System.out.println("\n\nQUESTION(S)");
			for (int c=0; c<qdcount; c++) {
				temp="";
				n=0;
				for (int j=i;;i++) {
					if (buffer[i]==0x00) break;
					s= Integer.toHexString(Integer.parseInt(Byte.toString(buffer[i]))); 
					if (s.length()>=2) s = s.substring(s.length()-2,s.length());
					else s = "0"+s;
					temp+=s;
				}
				System.out.print("  Nom: "+temp+"00 (");
				for (int j=0; j<temp.length();) {
					s = temp.substring(j,j+2);
					if (n==0) {
						n=Integer.decode("0x"+s);
						if (j!=0) System.out.print(".");
						j+=2;  
						continue;
					}
					System.out.print(new String(new byte[]{Integer.decode("0x"+s).byteValue()}));
					j+=2; n--;
				}
				System.out.print(")");
			}
			i++; temp="";
			for (int j=i; i<j+2; i++) {
				s = Integer.toHexString(Integer.parseInt(Byte.toString(buffer[i])));
				if (s.length()>=2) s = s.substring(s.length()-2,s.length());
				else s = "0"+s;
				temp += s;
			}
			System.out.print("\n  Type: "); System.out.print(temp+" ("+Integer.decode("0x"+temp)+")");
			temp="";
			for (int j=i; i<j+2; i++) {
				s = Integer.toHexString(Integer.parseInt(Byte.toString(buffer[i])));
				if (s.length()>=2) s = s.substring(s.length()-2,s.length());
				else s = "0"+s;
				temp += s;
			}
			System.out.print("\n  Class: "); System.out.print(temp+" ("+Integer.decode("0x"+temp)+")");
		}
		
		int rdlength, offset, type; String tmp;
		type=0;
		//Reponse
		if (ancount>0) {
			System.out.print("\n\nREPONSE(S)"); 
			for (int c=0; c<ancount; c++) {
				System.out.println();
				temp="";
				for (int j=i; i<j+2; i++) {
					s = Integer.toHexString(Integer.parseInt(Byte.toString(buffer[i])));
					if (s.length()>=2) s = s.substring(s.length()-2,s.length());
					else s = "0"+s;
					temp += s;
				}
				tmp = temp;
				offset = Integer.decode("0x"+temp.substring(2,temp.length()));
				System.out.print("\n  Nom: "+temp/*+" ("+name(buffer,offset)+")"*/); 
				temp="";
				for (int j=i; i<j+2; i++) {
					s = Integer.toHexString(Integer.parseInt(Byte.toString(buffer[i])));
					if (s.length()>=2) s = s.substring(s.length()-2,s.length());
					else s = "0"+s;
					//MODIF
					type = Integer.decode("0x"+s);
					//MODIF
					temp += s;
				}
				System.out.print("\n  Type: "); System.out.print(temp+" ("+Integer.decode("0x"+temp)+")");
				temp="";
				for (int j=i; i<j+2; i++) {
					s = Integer.toHexString(Integer.parseInt(Byte.toString(buffer[i])));
					if (s.length()>=2) s = s.substring(s.length()-2,s.length());
					else s = "0"+s;
					temp += s;
				}
				System.out.print("\n  Class: "); System.out.print(temp+" ("+Integer.decode("0x"+temp)+")");
				temp="";
				for (int j=i; i<j+4; i++) {
					s = Integer.toHexString(Integer.parseInt(Byte.toString(buffer[i])));
					if (s.length()>=2) s = s.substring(s.length()-2,s.length());
					else s = "0"+s;
					temp += s;
				}
				System.out.print("\n  TTL: "); System.out.print(temp+" ("+Integer.decode("0x"+temp)+")");
				temp="";
				for (int j=i; i<j+2; i++) {
					s = Integer.toHexString(Integer.parseInt(Byte.toString(buffer[i])));
					if (s.length()>=2) s = s.substring(s.length()-2,s.length());
					else s = "0"+s;
					temp += s;
				}
				rdlength = Integer.decode("0x"+temp);
				System.out.print("\n  RDLength: "); System.out.print(temp+" ("+rdlength+")");
				temp="";
				for (int j=i; i<j+rdlength; i++) {
					s = Integer.toHexString(Integer.parseInt(Byte.toString(buffer[i])));
					if (s.length()>=2) s = s.substring(s.length()-2,s.length());
					else s = "0"+s;
					temp += s;
				}
				System.out.print("\n  RDData: "+temp);
				if (type!=2)System.out.print("\n  >>> ");
				if (type==5) System.out.print(name(buffer,offset));
				if (type==1) System.out.print(InetAddress.getByName(name(buffer,offset)).getHostAddress());	
			}
		}
		
	}
	
	public static byte[] request(String label) throws IllegalRequestException {
		
		LinkedList<Byte> request = new LinkedList<Byte>();
		
		/*Header*/
		
		//id
		request.addLast(Byte.decode("0x08")); request.addLast((byte)0xbb);
		//params
		request.addLast(Byte.decode("0x01")); request.addLast(Byte.decode("0x00"));
		//QDCount
		request.addLast(Byte.decode("0x00")); request.addLast(Byte.decode("0x01")); 
		//ANCount
		request.addLast(Byte.decode("0x00")); request.addLast(Byte.decode("0x00")); request.addLast(Byte.decode("0x00"));
		request.addLast(Byte.decode("0x00")); request.addLast(Byte.decode("0x00")); request.addLast(Byte.decode("0x00"));
		
		int nbSep, count;
		LinkedList<Integer> l = new LinkedList<Integer>();
		
		/*Name - Question*/
		if (label.length()==0) throw new IllegalRequestException();
		if (label.charAt(0)=='.') throw new IllegalRequestException();
		count = nbSep = 0;
		//System.out.println(label.length());
		while (nbSep<label.length()) {
			//System.out.print(nbSep+"  ");
			if (label.charAt(nbSep++)=='.') {
				//System.out.print("un pt  "+count);
				l.addLast(count);
				if (label.length()>nbSep+1)
					if (label.charAt(nbSep+1)=='.') throw new IllegalRequestException();
				count=0;
				//System.out.println();
				continue;
			}
			count++;
			//System.out.println(count);
		}
		if (count!=0) l.addLast(count);
		String hex;
		hex = Integer.toHexString(l.removeFirst());
		if (hex.length()==1) request.addLast(Byte.decode("0x0"+hex));
		else request.addLast(Byte.decode("0x"+hex));
		//for (int i: l) System.out.print(i);
		for (Character c: label.toCharArray()) {
			if (c=='.') {
				hex = Integer.toHexString(l.removeFirst());
				//System.out.println("hex "+hex);
				if (hex.length()==1) request.addLast(Byte.decode("0x0"+hex));
				else request.addLast(Byte.decode("0x"+hex));
				continue;
			}
			request.addLast((new String(new char[]{c})).getBytes()[0]);
		}
		request.addLast(Byte.decode("0x00"));
		
		/*Type*/
		request.addLast(Byte.decode("0x00")); request.addLast(Byte.decode("0x01"));
		/*Class*/
		request.addLast(Byte.decode("0x0")); request.addLast(Byte.decode("0x1"));
		
		byte[] res = new byte[request.size()];
		int i=0;
		for (Byte b: request) res[i++]=b.byteValue();
		
		return res;
	}
	
	public static int IP2Int (String IPAddress) {
		String w, x, y, z; int i;
		w = x = y = z = ""; i=0;
		
		for (; i<IPAddress.length(); i++) {
			if (IPAddress.charAt(i)=='.') {i++; break;}
			w += IPAddress.charAt(i);
		}
		for (; i<IPAddress.length(); i++) {
			if (IPAddress.charAt(i)=='.') {i++; break;}
			x += IPAddress.charAt(i);
		}
		for (; i<IPAddress.length(); i++) {
			if (IPAddress.charAt(i)=='.') {i++; break;}
			y += IPAddress.charAt(i);
		}
		for (; i<IPAddress.length(); i++) z += IPAddress.charAt(i);
		
		return Integer.decode("0x"+Integer.toHexString(Integer.decode(w))+Integer.toHexString(Integer.decode(x))
				+Integer.toHexString(Integer.decode(y))+Integer.toHexString(Integer.decode(z)));
		
	}
	
	public static void main(String args[]) throws IllegalRequestException, UnknownHostException, IOException {
		
		byte[] buffer; 
		String name;
		DatagramPacket dp;
		
		name = "www.lifl.fr";
		
		buffer = request(name);
		
		UDP.Socket = new DatagramSocket();
		
		UDP.send(buffer,InetAddress.getByName("134.206.10.18"),PORT);
		
		dp = UDP.receive();
		
		answer(dp.getData());
		System.out.println(String2Int(name));
	}		
}
