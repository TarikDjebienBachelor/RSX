package exercice2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.UnknownHostException;

public class sendMulticastUDP {

	private MulticastSocket socket;
	private DatagramPacket packet;
	private int port;
	private byte[] buf;
	private static String message = "helloooooooooo";
	private InetAddress group;
	
	public sendMulticastUDP(int port){
	    this.port = port;
	    this.buf = new byte[512];
	    byte[] bytes = this.message.getBytes();
	    try {
			this.group = InetAddress.getByName("224.0.0.0");
		} catch (UnknownHostException e1) {
			e1.printStackTrace();
		}
	    try {
			this.socket = new MulticastSocket(port);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			this.socket.joinGroup(group);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void send(){
		while(true) {
			this.packet = new DatagramPacket(this.buf,this.buf.length,this.group, 7654);
			try {
				this.socket.send(this.packet);
			} catch(IOException e){
				
			}
		    //this.buf = this.packet.getData();
		    String s = new String(this.packet.getData());
		    System.out.println(s);
		    this.buf = new byte[512];
		}
	}
	
	  public static void main(String args[]) throws Exception {
		    int serverPort = 7654;
		    sendMulticastUDP envoi = new sendMulticastUDP(serverPort);
			envoi.send();
	  }
}
