package exercice2;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.net.UnknownHostException;

import exercice1.receiveUDP;

public class receiveMulticastUDP {

	private MulticastSocket socket;
	private DatagramPacket packet;
	private int port;
	private byte[] buf;
	private InetAddress group;
	
	
	public receiveMulticastUDP(int port){
	    this.port = port;
	    this.buf = new byte[512];
	    try {
			this.group = InetAddress.getByName("224.0.0.0");
		} catch (UnknownHostException e1) {
			e1.printStackTrace();
		}
	    try {
			this.socket = new MulticastSocket(port);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			this.socket.joinGroup(group);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	public void receive(){
		while(true) {
			this.packet = new DatagramPacket(this.buf,this.buf.length);
			try {
				this.socket.receive(this.packet);
			} catch(IOException e){
				
			}
		    //this.buf = this.packet.getData();
		    String s = new String(this.packet.getData());
		    System.out.println(s);
		    this.buf = new byte[512];
		}
	}
	
	
	  public static void main(String args[]) throws Exception {
		    int serverPort = 7654;
		    receiveMulticastUDP reception = new receiveMulticastUDP(serverPort);
			reception.receive();
	  }
}
