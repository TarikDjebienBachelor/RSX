package exercice1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class sendUDP {

	private DatagramPacket packet;	
	private DatagramSocket ds;
	private static int port;
	private static String message;
	private InetAddress hostAdress;
	
	public sendUDP(int port, String message) {
		try {
			this.port = port;
			this.ds = new DatagramSocket();
			this.message = message;
			this.hostAdress = InetAddress.getByName("127.0.0.1");
			byte[] bytes = this.message.getBytes();
			this.packet = new DatagramPacket(bytes,bytes.length,this.hostAdress , this.port);
		} catch (SocketException se) {
			System.out.println(se.getMessage());
		} catch (UnknownHostException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void send(){
		try {
			this.ds.send(this.packet);
		} catch(IOException e){
		}
	}
	
	public static void main(String[] args) {
		int port = 4343;
		String message = "Bonjourno";
		sendUDP sendudp = new sendUDP(port, message);
		sendudp.send();

	}
}
