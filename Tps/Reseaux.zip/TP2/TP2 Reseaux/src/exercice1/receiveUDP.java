package exercice1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;


//nc -u localhost 8899
public class receiveUDP {
	
	private DatagramPacket packet;	
	private DatagramSocket ds;
	private int port;
	private int bufSize;
	private byte[] buf;
	
	public receiveUDP(int port){
	    this.port = port;
	    this.bufSize = 1024;
	    this.buf = new byte[this.bufSize];
	    try {
	    	this.ds = new DatagramSocket(port);
	    } catch (SocketException e){
		}
	}
	
	public void receive(){
		this.packet = new DatagramPacket(this.buf,this.bufSize);
		try {
			this.ds.receive(this.packet);
		} catch(IOException e){
			
		}

	    this.buf = this.packet.getData();
	    String s = new String(buf);
	    System.out.println(s);
	}
	
	  public static void main(String args[]) throws Exception {
		    int serverPort = 8811;
		    receiveUDP reception = new receiveUDP(serverPort);
		    while(true) {
			    reception.receive();
		    }
	  }
}
