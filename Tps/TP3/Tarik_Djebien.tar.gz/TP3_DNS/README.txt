README : 

// Auteur : Djebien Tarik
// Date   : avril 2010
// Objet  : TP Réseaux : Interrogation d'un serveur DNS

Ci-Joint le TP numero 3 de RSX, tout est fonctionnel :

Arborescence de l'archive Tarik_Djebien.tar.gz :
    |
    |_____README.txt
    |
    |_____RSX_TP3.pdf
    |
    |_____exercice1/
    |             |________c/ Makefile envoiUDP.c
    |             |________java/ ecouteUDP.jar manifest-ex 
    |                               |____src/reception/ReceptionUDP.java
    |                               |____classes/reception/ReceptionUDP.class
    |
    |_____exercice2/ 
                    |________wiresharkDNS.jar (Notre application de resolution DNS usage: java -jar wiresharkDNS <addr_symbolique><Ip serveur DNS>
                    |________manifest-ex 
                    |________RequeteReponseDNS.pdf (exemple de trame UDP recuperer avec le logiciel wireshark pour une resolution DNS de www.lifl.fr)  
                    |________src/exercice2/ RequeteDNS.java ReponseDNS.java
                    |________classes/exercice2/ RequeteDNS.class ReponseDNS.class

Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr

Cordialement.
